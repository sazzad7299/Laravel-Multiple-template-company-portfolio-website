<div class="input-group mb-3"> <span class="input-group-text" id="basic-addon3">{{env('APP_URL')  }}</span>
    <input type="text" class="form-control" id="name" aria-describedby="basic-addon3">
</div>