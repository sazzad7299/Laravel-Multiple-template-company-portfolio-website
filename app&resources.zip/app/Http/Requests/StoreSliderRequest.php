<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class StoreSliderRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'title'=>'required',
            'description'=>'nullable',
            'category_id'=>'nullable',
            'position'=>'nullable',
            'button_text'=>'nullable',
            'button_url'=>'nullable',
            'feature_image'=>'required',
            'status'=>'nullable',
        ];
    }
}
